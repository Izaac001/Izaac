let xBolinha = 300; // Posição inicial X da bolinha
let yBolinha = 200; // Posição inicial Y da bolinha
let diametro = 15; // Diâmetro da bolinha

let velocidadeXBolinha = 6; // Velocidade da bolinha no eixo X
let velocidadeYBolinha = 6; // Velocidade da bolinha no eixo Y

function setup() {
    createCanvas(600, 400); // Cria uma tela de 600x400 pixels
}

function draw() {
    background(0); // Define o fundo como preto
    circle(xBolinha, yBolinha, diametro); // Desenha a bolinha

    // Atualiza a posição da bolinha
    xBolinha += velocidadeXBolinha; 
    yBolinha += velocidadeYBolinha; 

    // Verifica se a bolinha bateu nas bordas da tela e inverte a direção
    if (xBolinha > width - diametro / 2 || xBolinha < diametro / 2) {
        velocidadeXBolinha *= -1; // Inverte a direção no eixo X
    }

    if (yBolinha > height - diametro / 2 || yBolinha < diametro / 2) {
        velocidadeYBolinha *= -1; // Inverte a direção no eixo Y
    }
}